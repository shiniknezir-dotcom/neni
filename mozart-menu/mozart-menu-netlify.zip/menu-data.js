/* Mozart café · bistro · bar — menu data (German + English).
   Edit data/menu.json and run build-data.py, or edit this file directly: every text has a de and an en value. */
window.MOZART_MENU = {
 "info": {
  "name": "Mozart café · bistro · bar",
  "address": [
   "Theaterstr. 21",
   "97070 Würzburg"
  ],
  "phone": "0931 90704686",
  "web": "www.mozart-wuerzburg.de",
  "facebook": "Cafe Mozart Würzburg",
  "hours": {
   "de": "Montag bis Sonntag 9.00 bis 23.00",
   "en": "Monday to Sunday 9 am – 11 pm"
  }
 },
 "legend": {
  "allergens": [
   {
    "code": "1",
    "de": "glutenhaltiges Getreide*",
    "en": "cereals containing gluten*"
   },
   {
    "code": "1a",
    "de": "Weizen",
    "en": "wheat"
   },
   {
    "code": "1b",
    "de": "Roggen",
    "en": "rye"
   },
   {
    "code": "1c",
    "de": "Gerste",
    "en": "barley"
   },
   {
    "code": "2",
    "de": "Krebstiere*",
    "en": "crustaceans*"
   },
   {
    "code": "3",
    "de": "Eier*",
    "en": "eggs*"
   },
   {
    "code": "4",
    "de": "Fische*",
    "en": "fish*"
   },
   {
    "code": "5",
    "de": "Erdnüsse*",
    "en": "peanuts*"
   },
   {
    "code": "6",
    "de": "Sojabohnen*",
    "en": "soybeans*"
   },
   {
    "code": "7",
    "de": "Milch einschließlich Laktose*",
    "en": "milk incl. lactose*"
   },
   {
    "code": "8",
    "de": "Schalenfrüchte*",
    "en": "nuts*"
   },
   {
    "code": "8a",
    "de": "Mandeln",
    "en": "almonds"
   },
   {
    "code": "8b",
    "de": "Haselnuss",
    "en": "hazelnuts"
   },
   {
    "code": "8c",
    "de": "Walnuss",
    "en": "walnuts"
   },
   {
    "code": "8d",
    "de": "Macadamia",
    "en": "macadamia"
   },
   {
    "code": "9",
    "de": "Sellerie*",
    "en": "celery*"
   },
   {
    "code": "10",
    "de": "Senf*",
    "en": "mustard*"
   },
   {
    "code": "11",
    "de": "Sesamsamen*",
    "en": "sesame seeds*"
   },
   {
    "code": "12",
    "de": "Schwefeldioxid und Sulfite*",
    "en": "sulphur dioxide and sulphites*"
   },
   {
    "code": "13",
    "de": "Lupinen*",
    "en": "lupin*"
   },
   {
    "code": "14",
    "de": "Weichtiere*",
    "en": "molluscs*"
   }
  ],
  "additives": [
   {
    "code": "A",
    "de": "mit Farbstoff",
    "en": "with colouring"
   },
   {
    "code": "B",
    "de": "mit Konservierungsstoffen",
    "en": "with preservatives"
   },
   {
    "code": "C",
    "de": "koffeinhaltig",
    "en": "contains caffeine"
   },
   {
    "code": "D",
    "de": "chininhaltig",
    "en": "contains quinine"
   },
   {
    "code": "E",
    "de": "mit Süßungsmitteln",
    "en": "with sweeteners"
   },
   {
    "code": "F",
    "de": "enthält eine Phenylalaninquelle",
    "en": "contains a source of phenylalanine"
   },
   {
    "code": "G",
    "de": "mit Antioxidationsmittel",
    "en": "with antioxidants"
   }
  ],
  "footnote": {
   "de": "* und daraus gewonnene Erzeugnisse",
   "en": "* and products made from them"
  }
 },
 "sections": [
  {
   "id": "fruehstueck",
   "group": "food",
   "tempo": "Ouvertüre",
   "title": {
    "de": "Frühstück",
    "en": "Breakfast"
   },
   "subtitle": {
    "de": "bis 14 Uhr",
    "en": "until 2 pm"
   },
   "note": {
    "de": "lecker & gesund in den Tag",
    "en": "a delicious & healthy start to the day"
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-03",
    "page-04"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Zimtporridge",
        "en": "Cinnamon porridge"
       },
       "description": {
        "de": "mit frischen Früchten & Mandelmilch",
        "en": "with fresh fruit & almond milk"
       },
       "allergens": "8a,8c",
       "prices": [
        {
         "size": "",
         "price": 7.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Großer Joghurt",
        "en": "Large yoghurt"
       },
       "description": {
        "de": "mit frischen & getrockneten Früchten, Nüssen & Müsli",
        "en": "with fresh & dried fruit, nuts & muesli"
       },
       "allergens": "1a,7,8c",
       "prices": [
        {
         "size": "",
         "price": 6.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Früchtchen",
        "en": "Früchtchen (the fruity one)"
       },
       "description": {
        "de": "Kornspitz, Joghurt mit frischen Früchten, Konfitüre & Butter",
        "en": "Kornspitz roll, yoghurt with fresh fruit, jam & butter"
       },
       "allergens": "1a,1b,6,7,8c",
       "prices": [
        {
         "size": "",
         "price": 6.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Schinkenfrühstück",
        "en": "Ham breakfast"
       },
       "description": {
        "de": "Kornspitz und Ciabatta, Platte mit italienischem Schinken(B,G), luftgetrockneter Salami(B,G) & Butter",
        "en": "Kornspitz roll and ciabatta, platter of Italian ham(B,G), air-dried salami(B,G) & butter"
       },
       "allergens": "1a,1b,6,7,8c,11",
       "prices": [
        {
         "size": "",
         "price": 8.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Fitness Frühstück",
        "en": "Fitness breakfast"
       },
       "description": {
        "de": "2 Rühreier mit Avocado, körnigem Frischkäse und frischem Salat und ein Proteinbrötchen",
        "en": "2 scrambled eggs with avocado, cottage cheese and fresh salad, plus a protein roll"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 10.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": "Keine Allergencodes auf der Karte gedruckt."
      },
      {
       "name": {
        "de": "Karma",
        "en": "Karma"
       },
       "description": {
        "de": "Brotkorb mit Ciabatta, Kornspitz & Croissant, Platte mit italienischem Schinken(B,G) & verschiedenen Käsesorten, Tomate, Mozzarella, dazu ein Joghurt mit frischen Früchten, luftgetrockneter Salami(B), Konfitüre, Nutella & Butter",
        "en": "Bread basket with ciabatta, Kornspitz roll & croissant, platter of Italian ham(B,G) & a selection of cheeses, tomato, mozzarella, plus a yoghurt with fresh fruit, air-dried salami(B), jam, Nutella & butter"
       },
       "allergens": "1a,1b,3,6,7,8c,11",
       "prices": [
        {
         "size": "",
         "price": 14.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Vegetarisches Karma",
        "en": "Vegetarian Karma"
       },
       "description": {
        "de": "Brotkorb mit Vitalweckerl, Kornspitz & Croissant, Platte mit verschiedenen Käsesorten, Gemüse & Kräuterrahmdip, Tomate, Mozzarella, dazu ein Joghurt mit frischen Früchten, Konfitüre, Honig & Butter",
        "en": "Bread basket with Vitalweckerl (multigrain roll), Kornspitz roll & croissant, platter of a selection of cheeses, vegetables & creamy herb dip, tomato, mozzarella, plus a yoghurt with fresh fruit, jam, honey & butter"
       },
       "allergens": "1a,1b,3,6,7,8c,11",
       "prices": [
        {
         "size": "",
         "price": 14.5
        }
       ],
       "tags": [
        "vegetarisch"
       ],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Karma / Veg. Karma für Zwei",
        "en": "Karma / Veg. Karma for two"
       },
       "description": {
        "de": "Wie oben, aber großer Brotkorb, zweimal Joghurt und zweimal frisch gepresster O-Saft",
        "en": "As above, but with a large bread basket, two yoghurts and two freshly squeezed orange juices"
       },
       "allergens": "1a,1b,3,6,7,8c,11,B,G",
       "prices": [
        {
         "size": "",
         "price": 24.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Veganes Frühstück",
        "en": "Vegan breakfast"
       },
       "description": {
        "de": "Vitalweckerl mit einem Soja-Früchte-Joghurt, selbstgemachter Hummus & Avocadocreme",
        "en": "Vitalweckerl (multigrain roll) with a soya fruit yoghurt, homemade hummus & avocado cream"
       },
       "allergens": "1a,1b,6,8c,11",
       "prices": [
        {
         "size": "",
         "price": 8.5
        }
       ],
       "tags": [
        "vegan"
       ],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mozart",
        "en": "Mozart"
       },
       "description": {
        "de": "Brotkorb mit Vitalweckerl, Ciabatta & Croissant, weiches Frühstücksei, Platte mit Tomate & Mozzarella, Räucherlachs(B), Butter & Honig, dazu ein Glas Prosecco oder frisch gepresster O-Saft",
        "en": "Bread basket with Vitalweckerl (multigrain roll), ciabatta & croissant, soft-boiled egg, platter of tomato & mozzarella, smoked salmon(B), butter & honey, plus a glass of Prosecco or freshly squeezed orange juice"
       },
       "allergens": "1a,1b,3,4,6,7,8c,10,11",
       "prices": [
        {
         "size": "",
         "price": 15.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mozart für Zwei",
        "en": "Mozart for two"
       },
       "description": {
        "de": "Wie oben, aber großer Brotkorb, zwei Eier & zwei Gläser Prosecco oder O-Saft",
        "en": "As above, but with a large bread basket, two eggs & two glasses of Prosecco or orange juice"
       },
       "allergens": "1a,1b,3,4,6,7,8c,10,11",
       "prices": [
        {
         "size": "",
         "price": 25.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Lust auf mehr? Fragen Sie uns!",
      "en": "Fancy a little extra? Just ask us!"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "extra Lachs",
        "en": "Extra salmon"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 5.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "extra Frischkäse / Butter",
        "en": "Extra cream cheese / butter"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 1.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "extra Avocadocreme",
        "en": "Extra avocado cream"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 2.0
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": "Letzte Ziffer berührt den Fotorand, auf vergrößertem Ausschnitt aber klar als 2,00 lesbar."
      },
      {
       "name": {
        "de": "extra Hummus",
        "en": "Extra hummus"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": null
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Preis am Fotorand abgeschnitten: nur '2,0' lesbar (vermutlich 2,00). Bitte prüfen."
      },
      {
       "name": {
        "de": "Joghurt mit Früchten",
        "en": "Yoghurt with fruit"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": null
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Preis am Fotorand abgeschnitten: nur '3,5' lesbar (3,50 oder 3,5x). Bitte prüfen."
      },
      {
       "name": {
        "de": "Französisches Croissant",
        "en": "French croissant"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": null
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Preis am Fotorand abgeschnitten: nur '2,' und der Ansatz einer Ziffer lesbar. Bitte prüfen."
      },
      {
       "name": {
        "de": "Frühstücksei",
        "en": "Breakfast egg"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": null
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Preis am Fotorand abgeschnitten: nur die führende '1' lesbar. Bitte prüfen."
      }
     ]
    }
   ]
  },
  {
   "id": "eier",
   "group": "food",
   "tempo": "Allegro",
   "title": {
    "de": "Ei Ei Ei…",
    "en": "Eggs, eggs, eggs…"
   },
   "subtitle": {
    "de": "bis 14 Uhr",
    "en": "until 2 pm"
   },
   "note": {
    "de": "vom freilaufenden Huhn",
    "en": "from free-range hens"
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-03"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Zwei Eier im Glas",
        "en": "Two soft-boiled eggs in a glass"
       },
       "description": {
        "de": "mit Ciabatta & Butter",
        "en": "with ciabatta & butter"
       },
       "allergens": "1a,1b,3,11",
       "prices": [
        {
         "size": "",
         "price": 6.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Omelett mit Speck & Zwiebeln",
        "en": "Omelette with bacon & onions"
       },
       "description": {
        "de": "dazu Ciabatta & Butter",
        "en": "served with ciabatta & butter"
       },
       "allergens": "1a,1b,3,11",
       "prices": [
        {
         "size": "",
         "price": 8.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Omelett mit Lauch & Champignons",
        "en": "Omelette with leek & mushrooms"
       },
       "description": {
        "de": "dazu Ciabatta & Butter",
        "en": "served with ciabatta & butter"
       },
       "allergens": "1a,1b,3,11",
       "prices": [
        {
         "size": "",
         "price": 8.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Rührei aus drei Eiern mit warmem Ciabatta & Butter",
      "en": "Three-egg scramble with warm ciabatta & butter"
     },
     "note": {
      "de": "Allergene der Gruppe: 1a,1b,3,11",
      "en": "Allergens for this group: 1a,1b,3,11"
     },
     "items": [
      {
       "name": {
        "de": "Rührei Natur",
        "en": "Plain scrambled eggs"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mit Tomatenwürfeln & Mozzarella",
        "en": "With diced tomatoes & mozzarella"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 8.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mit italienischem Schinken & Käse",
        "en": "With Italian ham & cheese"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "B,G,7",
       "prices": [
        {
         "size": "",
         "price": 8.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": "Gedruckt als Schinken(B,G) & Käse(7)."
      },
      {
       "name": {
        "de": "Mit Feta und bunten Paprikastreifen",
        "en": "With feta & colourful bell pepper strips"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 8.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mit Ziegenkäse & Rucola",
        "en": "With goat's cheese & rocket"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 8.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mit Sudzuk",
        "en": "With sucuk (spicy beef sausage)"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 8.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Drei Spiegeleier",
        "en": "Three fried eggs"
       },
       "description": {
        "de": "mit Bacon(B,G), Ciabatta & Butter",
        "en": "with bacon(B,G), ciabatta & butter"
       },
       "allergens": "1a,1b,3,6,7,11",
       "prices": [
        {
         "size": "",
         "price": 8.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "kleiner-hunger",
   "group": "food",
   "tempo": "Intermezzo",
   "title": {
    "de": "… für den kleinen Hunger",
    "en": "… for small appetites"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-01",
    "page-02"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Ofenwarme Brezel",
        "en": "Oven-warm pretzel"
       },
       "description": {
        "de": "mit Butter",
        "en": "with butter"
       },
       "allergens": "1a,6,7,11",
       "prices": [
        {
         "size": "",
         "price": 3.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Tomaten-Mozzarella-Stange",
        "en": "Tomato & mozzarella roll"
       },
       "description": {
        "de": "Kornspitz mit Tomate und Mozzarella",
        "en": "Kornspitz (crusty multigrain roll) with tomato and mozzarella"
       },
       "allergens": "1a,1b,7,11",
       "prices": [
        {
         "size": "",
         "price": 4.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Bagel",
      "en": "Bagel"
     },
     "note": {
      "de": "Allergene: 1a,4,7,11",
      "en": "Allergens: 1a,4,7,11"
     },
     "items": [
      {
       "name": {
        "de": "mit Lachs, Avocadocreme, Salat und Gurke",
        "en": "with salmon, avocado cream, lettuce and cucumber"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 5.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "mit Hummus, Salat, Zucchini und getrockneten Tomaten",
        "en": "with hummus, lettuce, zucchini and sun-dried tomatoes"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 5.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "mit Guacamole, Salat, Speck und Ei",
        "en": "with guacamole, lettuce, bacon and egg"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Männerbrötchen",
        "en": "Männerbrötchen"
       },
       "description": {
        "de": "Ciabatta mit getrockneten Tomaten, Rucola und italienischem Schinken",
        "en": "“Men’s roll” – ciabatta with sun-dried tomatoes, rocket and Italian ham"
       },
       "allergens": "1a,1b,3,11,8,6",
       "prices": [
        {
         "size": "",
         "price": 4.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "ofenkartoffel",
   "group": "food",
   "tempo": "Divertimento",
   "title": {
    "de": "Gefüllte überbackene Ofenkartoffel",
    "en": "Stuffed baked potato au gratin"
   },
   "subtitle": {
    "de": "ab 11.30 Uhr",
    "en": "from 11:30 am"
   },
   "note": {
    "de": "dazu gibt's Kräutersauerrahm(7)",
    "en": "served with herb sour cream(7)"
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-02"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Mit Tomate & Mozzarella",
        "en": "With tomato & mozzarella"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 9.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mit frischem Gemüse & Camembert",
        "en": "With fresh vegetables & Camembert"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 9.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mit Lachs & Camembert",
        "en": "With salmon & Camembert"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "4,7,9,3",
       "prices": [
        {
         "size": "",
         "price": 10.5
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Hochgestellte Codes sehr klein: Lachs(4), Camembert(7,4,9,3) – letzte Ziffer könnte auch '8' sein. Preis 10,50 klar."
      }
     ]
    }
   ]
  },
  {
   "id": "flammkuchen",
   "group": "food",
   "tempo": "Capriccio",
   "title": {
    "de": "Flammkuchen",
    "en": "Flammkuchen (Alsatian tarte flambée)"
   },
   "subtitle": {
    "de": "ab 11.30 Uhr",
    "en": "from 11:30 am"
   },
   "note": {
    "de": "Hauchdünn mit Crème fraîche & Kräutern, frisch belegt und knusprig gebacken",
    "en": "Wafer-thin, with crème fraîche & herbs, freshly topped and baked until crisp"
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-02"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Mit Räucherschinken",
        "en": "With smoked ham"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 9.7
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Nur 'Mit Räuche…' lesbar (Handschatten). 'Räucherschinken' ist eine Vermutung – bitte prüfen, evtl. '& Zwiebeln' ergänzen."
      },
      {
       "name": {
        "de": "Mit Tomaten, Mozzarella & Basilikum",
        "en": "With tomatoes, mozzarella & basil"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 9.7
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Nur 'Mit Tomaten, …' lesbar; Rest vermutet (schwach 'Mozz…' erkennbar). Bitte prüfen."
      },
      {
       "name": {
        "de": "Mit Rucola, italienischem Schinken & Parmesan",
        "en": "With rocket, Italian ham & parmesan"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 12.9
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Lesbar: 'Mit Rucola, italie… & Parmesan'; 'italienischem Schinken' ergänzt. Bitte prüfen."
      },
      {
       "name": {
        "de": "Mit geräuchertem Lachs und Brie",
        "en": "With smoked salmon and Brie"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 13.9
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Lesbar: 'Mit geräuchertem L… … Brie'; 'Lachs und' ergänzt. Bitte prüfen."
      },
      {
       "name": {
        "de": "Mit Sudzuk (Rindersalami)",
        "en": "With sucuk (spicy beef sausage)"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 11.9
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Lesbar: 'Mit Sudzuk (Rinder S…)'; Klammerinhalt vermutet. Bitte prüfen."
      }
     ]
    }
   ]
  },
  {
   "id": "essen",
   "group": "food",
   "tempo": "Sinfonia",
   "title": {
    "de": "Essen im Mozart",
    "en": "Dining at Mozart"
   },
   "subtitle": {
    "de": "ab 11.30 Uhr",
    "en": "from 11:30 am"
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-05"
   ],
   "groups": [
    {
     "title": {
      "de": "Suppen",
      "en": "Soups"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Tomatencremesuppe",
        "en": "Cream of tomato soup"
       },
       "description": {
        "de": "mit Schlagsahne",
        "en": "with whipped cream"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Antipasti",
      "en": "Antipasti"
     },
     "note": {
      "de": "mit Brot(1a,1b,11) serviert",
      "en": "served with bread(1a,1b,11)"
     },
     "items": [
      {
       "name": {
        "de": "Ziegenkäse",
        "en": "Goat's cheese"
       },
       "description": {
        "de": "im Speckmantel auf Rucolasalat",
        "en": "wrapped in bacon on a rocket salad"
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 11.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Vitello Tonnato",
        "en": "Vitello Tonnato"
       },
       "description": {
        "de": "fein geschnittene Scheiben von Kalb mit Thunfischsoße und Kapern",
        "en": "thinly sliced veal with tuna sauce and capers"
       },
       "allergens": "4,7,8",
       "prices": [
        {
         "size": "",
         "price": 15.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Capreseteller",
        "en": "Caprese plate"
       },
       "description": {
        "de": "Tomaten und Mozzarella mit frischem Basilikum",
        "en": "tomatoes and mozzarella with fresh basil"
       },
       "allergens": "1a,1b,6,7,11",
       "prices": [
        {
         "size": "",
         "price": 10.2
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Hochgestellte Codes winzig: '6' könnte auch '8' sein."
      },
      {
       "name": {
        "de": "Räucherlachs",
        "en": "Smoked salmon"
       },
       "description": {
        "de": "mit hausgemachtem Kartoffelpuffer",
        "en": "with a homemade potato pancake (Kartoffelpuffer)"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 13.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Italienische Antipasti",
        "en": "Italian antipasti"
       },
       "description": {
        "de": "gebratenes Gemüse mit italienischem Schinken(B,G) & Tomate-Mozzarella & Brot",
        "en": "roasted vegetables with Italian ham(B,G), tomato & mozzarella and bread"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 15.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Käseplatte",
        "en": "Cheese platter"
       },
       "description": {
        "de": "mit verschiedenen Käsesorten, Oliven und Trauben",
        "en": "with a selection of cheeses, olives and grapes"
       },
       "allergens": "1a,1b,7,11",
       "prices": [
        {
         "size": "",
         "price": 11.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Salat",
      "en": "Salads"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Gemischter Salat",
        "en": "Mixed salad"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "klein",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Bunter Salat",
        "en": "Colourful salad"
       },
       "description": {
        "de": "mit Putenstreifen, Champignons und Parmesan",
        "en": "with turkey strips, mushrooms and parmesan"
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 15.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "hauptspeisen",
   "group": "food",
   "tempo": "Finale",
   "title": {
    "de": "Hauptspeisen",
    "en": "Main courses"
   },
   "subtitle": {
    "de": "ab 11.30 Uhr",
    "en": "from 11:30 am"
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-06"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Penne mit Garnelen",
        "en": "Penne with prawns"
       },
       "description": {
        "de": "und Rucola in Weißwein-Zitronensoße",
        "en": "and rocket in a white wine & lemon sauce"
       },
       "allergens": "8,1a,4,12",
       "prices": [
        {
         "size": "",
         "price": 17.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Gefüllte Nudeln",
        "en": "Stuffed pasta"
       },
       "description": {
        "de": "mit Feigen und Pecorino in Butter und Salbei",
        "en": "with figs and pecorino in sage butter"
       },
       "allergens": "1a,7",
       "prices": [
        {
         "size": "",
         "price": 15.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Hausgemachte Lasagne",
        "en": "Homemade lasagne"
       },
       "description": {
        "de": "mit Rindfleisch und Parmesan",
        "en": "with beef and parmesan"
       },
       "allergens": "1a,7,9",
       "prices": [
        {
         "size": "",
         "price": 15.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Käsespätzle",
        "en": "Käsespätzle"
       },
       "description": {
        "de": "mit Zwiebeln und Salat",
        "en": "cheese spätzle (soft egg noodles baked with cheese) with onions and a side salad"
       },
       "allergens": "1a,7",
       "prices": [
        {
         "size": "",
         "price": 14.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Original Wiener Schnitzel",
        "en": "Original Wiener Schnitzel"
       },
       "description": {
        "de": "Kalbsfleisch, Pommes und Preiselbeeren",
        "en": "breaded veal escalope, fries and lingonberries"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 28.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Roastbeef vom Grill",
        "en": "Grilled roast beef"
       },
       "description": {
        "de": "mit Rosmarinkartoffeln und Gemüse",
        "en": "with rosemary potatoes and vegetables"
       },
       "allergens": "3,7",
       "prices": [
        {
         "size": "",
         "price": 29.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Burger mit Pommes",
        "en": "Burger with fries"
       },
       "description": {
        "de": "200g Rindfleisch, Tomaten, Salat, Zwiebeln, BBQ Soße(12)",
        "en": "200g beef patty, tomato, lettuce, onions, BBQ sauce(12)"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 18.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mozart Burger",
        "en": "Mozart Burger"
       },
       "description": {
        "de": "mit Entrecote, Ei, Rucola, Röstzwiebeln, Tomaten und Pommes",
        "en": "with entrecôte, egg, rocket, crispy fried onions, tomato and fries"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 19.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Hähnchenschnitzel",
        "en": "Chicken schnitzel"
       },
       "description": {
        "de": "mit Pommes und Salat",
        "en": "with fries and salad"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 17.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "suesses",
   "group": "food",
   "tempo": "Dolce",
   "title": {
    "de": "Lust auf was Süßes…",
    "en": "Fancy something sweet…"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-01"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "Kuchen finden Sie auf unserer täglich wechselnden Vitrine...",
      "en": "You'll find our cakes in the display case – the selection changes daily..."
     },
     "items": [
      {
       "name": {
        "de": "Belgische Waffel",
        "en": "Belgian waffle"
       },
       "description": {
        "de": "warm & mit Puderzucker",
        "en": "served warm & dusted with icing sugar"
       },
       "allergens": "1a,3,6",
       "prices": [
        {
         "size": "",
         "price": 4.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Warmer Apfelstrudel",
        "en": "Warm apple strudel"
       },
       "description": {
        "de": "mit Vanilleeis(3,7) & Sahne(7)",
        "en": "with vanilla ice cream(3,7) & cream(7)"
       },
       "allergens": "1a,3,8b",
       "prices": [
        {
         "size": "",
         "price": 6.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Kaiserschmarrn",
        "en": "Kaiserschmarrn"
       },
       "description": {
        "de": "mit Vanilleeis(3,7) & Apfelmus",
        "en": "shredded pancake with vanilla ice cream(3,7) & apple sauce"
       },
       "allergens": "1a,3",
       "prices": [
        {
         "size": "",
         "price": 7.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "kaffee",
   "group": "drinks",
   "tempo": "Andante",
   "title": {
    "de": "Kaffeespezialitäten",
    "en": "Coffee specialities"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "Alle unsere Kaffeespezialitäten werden aus frisch gemahlenen Bohnen höchster Qualität von der Rosenheimer Kaffeerösterei „Dinzler“ zubereitet.\n\nSie können wählen zwischen einem reinen, sehr vollmundigen Robusta „Roma“ und einer milden Mischung aus Robusta und Arabica, dem mehrfach ausgezeichneten „Il Gustoso“. Fragen Sie nach unserem wechselnden Bio-Espresso in der Sondermühle!\n\nAlle unsere Kaffeespezialitäten sind auch koffeinfrei und mit Soja- oder laktosefreier Milch erhältlich!",
    "en": "All our coffee specialities are made from freshly ground, top-quality beans from the Rosenheim roastery “Dinzler”.\n\nChoose between a pure, very full-bodied Robusta “Roma” and a mild blend of Robusta and Arabica, the multi-award-winning “Il Gustoso”. Ask about our rotating organic espresso, ground in its own dedicated grinder!\n\nAll our coffee specialities are also available decaffeinated and with soy or lactose-free milk!"
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-07"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Espresso",
        "en": "Espresso"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "C",
       "prices": [
        {
         "size": "",
         "price": 2.2
        },
        {
         "size": "groß",
         "price": 3.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Espresso Macchiato",
        "en": "Espresso Macchiato"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7,C",
       "prices": [
        {
         "size": "",
         "price": 2.5
        },
        {
         "size": "groß",
         "price": 4.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Café Crème",
        "en": "Café Crème"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "C",
       "prices": [
        {
         "size": "",
         "price": 3.2
        },
        {
         "size": "groß",
         "price": 4.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Cappuccino",
        "en": "Cappuccino"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7,C",
       "prices": [
        {
         "size": "",
         "price": 3.4
        },
        {
         "size": "groß",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Latte Macchiato",
        "en": "Latte Macchiato"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7,C",
       "prices": [
        {
         "size": "",
         "price": 3.9
        },
        {
         "size": "groß",
         "price": 5.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Milchkaffee",
        "en": "Milchkaffee (café au lait)"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "C",
       "prices": [
        {
         "size": "groß",
         "price": 4.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": "Nur ein Preis (4,50) in der Spalte 'groß' gedruckt; Allergencode steht als ',C' (vermutlich fehlt eine '7' für Milch)."
      },
      {
       "name": {
        "de": "Tasse Kaffee",
        "en": "Cup of coffee"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "C",
       "prices": [
        {
         "size": "",
         "price": 2.9
        },
        {
         "size": "groß",
         "price": 4.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Extras",
      "en": "Extras"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Schuss Sirup",
        "en": "Shot of syrup"
       },
       "description": {
        "de": "Schoko, Caramel, Haselnuss(8), Macadamia(8), Weiße Schokolade, Cocos, Vanille, Mandel(8)",
        "en": "chocolate, caramel, hazelnut(8), macadamia(8), white chocolate, coconut, vanilla, almond(8)"
       },
       "allergens": "B",
       "prices": [
        {
         "size": "",
         "price": 0.4
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Ende des Wortes 'Macadamia' samt Code durch Glanzlicht verdeckt; aus der Legende (8d Macadamia) ergänzt."
      },
      {
       "name": {
        "de": "Extra Sojamilch",
        "en": "Extra soy milk"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 0.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Extra laktosefreie Milch",
        "en": "Extra lactose-free milk"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 0.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Extra Hafermilch",
        "en": "Extra oat milk"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 0.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Extra Sahne",
        "en": "Extra cream"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 0.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "heisses",
   "group": "drinks",
   "tempo": "Con calore",
   "title": {
    "de": "noch mehr Heißes",
    "en": "Even more hot drinks"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-08"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Milchschokoladen-Kakao",
        "en": "Milk chocolate cocoa"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 3.9
        },
        {
         "size": "groß 0,5l",
         "price": 5.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Marrochino",
        "en": "Marrochino"
       },
       "description": {
        "de": "Milchschokoladenkakao mit Espresso",
        "en": "milk chocolate cocoa with a shot of espresso"
       },
       "allergens": "7,C",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.4
        },
        {
         "size": "groß 0,5l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Weiße Schokolade",
        "en": "White hot chocolate"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7,A",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.1
        },
        {
         "size": "groß 0,5l",
         "price": 6.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Marrochino Blanc",
        "en": "Marrochino Blanc"
       },
       "description": {
        "de": "Weiße Schokolade mit Espresso",
        "en": "white hot chocolate with a shot of espresso"
       },
       "allergens": "7,A,C",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.5
        },
        {
         "size": "groß 0,5l",
         "price": 7.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Chai Latte",
        "en": "Chai latte"
       },
       "description": {
        "de": "Gemahlener Gewürztee mit Milchschaum in den Sorten Tiger Spice, Vanilla",
        "en": "ground spiced tea with frothed milk, available as Tiger Spice or Vanilla"
       },
       "allergens": "7",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.5
        },
        {
         "size": "groß 0,5l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Chai Latte koffein- und zuckerfrei",
        "en": "Chai latte, caffeine- & sugar-free"
       },
       "description": {
        "de": "Flamingo Vanille",
        "en": "Flamingo Vanilla"
       },
       "allergens": "7",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.5
        },
        {
         "size": "groß 0,5l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Chai Latte mit Espresso",
        "en": "Chai latte with espresso"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7,C",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.9
        },
        {
         "size": "groß 0,5l",
         "price": 7.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Schweizer Schokolade mit Sahne",
        "en": "Swiss hot chocolate with cream"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "7",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.6
        },
        {
         "size": "groß 0,5l",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Matcha Latte",
        "en": "Matcha latte"
       },
       "description": {
        "de": "grüner getrockneter Tee mit Milch",
        "en": "finely ground green tea with milk"
       },
       "allergens": "",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.6
        },
        {
         "size": "groß 0,5l",
         "price": 7.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Pink Chai Latte",
        "en": "Pink chai latte"
       },
       "description": {
        "de": "Kokos, rote Bete, Goji-Beeren",
        "en": "coconut, beetroot, goji berries"
       },
       "allergens": "",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.6
        },
        {
         "size": "groß 0,5l",
         "price": 7.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Golden Chai Latte",
        "en": "Golden chai latte"
       },
       "description": {
        "de": "Kurkuma, Kardamom, Zimt",
        "en": "turmeric, cardamom, cinnamon"
       },
       "allergens": "",
       "prices": [
        {
         "size": "klein 0,3l",
         "price": 4.6
        },
        {
         "size": "groß 0,5l",
         "price": 7.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "tee",
   "group": "drinks",
   "tempo": "Adagio",
   "title": {
    "de": "Tee",
    "en": "Tea"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-09",
    "page-10"
   ],
   "groups": [
    {
     "title": {
      "de": "Schwarzer Tee",
      "en": "Black tea"
     },
     "note": {
      "de": "belebt Körper und Geist",
      "en": "invigorates body and mind"
     },
     "items": [
      {
       "name": {
        "de": "Assam Mangalam",
        "en": "Assam Mangalam"
       },
       "description": {
        "de": "Kräftiger, malziger Teegenuss aus der Assam-Hochebene im Norden Indiens",
        "en": "Strong, malty tea from the Assam plateau in northern India"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Darjeeling Pussimbing",
        "en": "Darjeeling Pussimbing"
       },
       "description": {
        "de": "Fruchtig-blumiger Charakter aus biologischem Anbau an den Südhängen des Himalaya",
        "en": "Fruity, floral character – organically grown on the southern slopes of the Himalayas"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Earl Grey",
        "en": "Earl Grey"
       },
       "description": {
        "de": "Der zitrusfruchtige Klassiker – intensiv duftend und angenehm verfeinert mit edelstem Bergamotte-Aroma",
        "en": "The citrusy classic – intensely fragrant and delicately refined with the finest bergamot aroma"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Grüner Tee",
      "en": "Green tea"
     },
     "note": {
      "de": "hohe Teekunst – gesunder Genuss",
      "en": "the high art of tea – healthy indulgence"
     },
     "items": [
      {
       "name": {
        "de": "China Wuyuan Jasmine",
        "en": "China Wuyuan Jasmine"
       },
       "description": {
        "de": "Feinster fruchtig-weicher und duftiger Jasmintee aus biologischem Anbau",
        "en": "Finest organic jasmine tea – fruity, mellow and wonderfully fragrant"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mao Feng",
        "en": "Mao Feng"
       },
       "description": {
        "de": "Purer, frischer Teegenuss aus biologischem Anbau im südindischen Garten Manjolai",
        "en": "Pure, fresh tea – organically grown on the Manjolai estate in southern India"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Morgentau",
        "en": "Morgentau"
       },
       "description": {
        "de": "China – aromatisierter grüner Blatt-Tee mit Mango-Zitronengeschmack",
        "en": "“Morning dew” – flavoured green leaf tea from China with mango & lemon"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "nicht schwarz, nicht grün, sondern…",
      "en": "neither black nor green, but…"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Rooibos Tee Cream Orange",
        "en": "Rooibos tea Cream Orange"
       },
       "description": {
        "de": "Aromatisierter Kräutertee mit Vanille-Orange-Geschmack",
        "en": "Flavoured herbal tea with vanilla & orange"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Lemon-Fresh",
        "en": "Lemon-Fresh"
       },
       "description": {
        "de": "Aromatisierter Früchtetee mit Zitronen-Geschmack",
        "en": "Flavoured fruit tea with a zesty lemon taste"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Minze Tee",
        "en": "Mint tea"
       },
       "description": {
        "de": "Würziger und kühlender Genuss für jede Jahreszeit aus biologischem Anbau",
        "en": "Aromatic and refreshingly cool, organically grown – a treat for every season"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Sweet Berries",
        "en": "Sweet Berries"
       },
       "description": {
        "de": "Aromatisierter Früchtetee mit Erdbeer-Himbeer-Geschmack",
        "en": "Flavoured fruit tea with strawberry & raspberry"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Kamillentee",
        "en": "Camomile tea"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "Kännchen",
         "price": 4.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Ayurvedatee",
      "en": "Ayurveda tea"
     },
     "note": {
      "de": "Stärkung der Einheit von Körper, Geist und Seele. Unsere Ayurvedatees von TeeGschwendner wurden auf der Grundlage der Lehre von den drei verschiedenen Lebensenergien Vata, Pitta und Kapha konzipiert. In den Tees finden Sie nur beste Kräuter und Gewürze aus biologischem Anbau, die durch ihre ganz besondere Komposition sicherlich alle Teeliebhaber begeistern werden.",
      "en": "Strengthening the unity of body, mind and soul. Our Ayurveda teas from TeeGschwendner are based on the teaching of the three different life energies Vata, Pitta and Kapha. They contain only the finest organically grown herbs and spices, whose very special composition is sure to delight every tea lover."
     },
     "items": [
      {
       "name": {
        "de": "Ayurveda Vata Tee „Kraft“",
        "en": "Ayurveda Vata tea “Strength”"
       },
       "description": {
        "de": "Ingwer, Anis, Koriander, Malvenblüten",
        "en": "Ginger, anise, coriander, mallow blossoms"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Glas",
         "price": 3.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Ayurveda Kapha Tee „Seele“",
        "en": "Ayurveda Kapha tea “Soul”"
       },
       "description": {
        "de": "Galgant (eine besondere Ingwerart), Melissenblätter, Fenchel, Petersilie, Kardamom und Kreuzkümmel",
        "en": "Galangal (a special kind of ginger), lemon balm leaves, fennel, parsley, cardamom and cumin"
       },
       "allergens": "",
       "prices": [
        {
         "size": "Glas",
         "price": 3.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "gesund",
   "group": "drinks",
   "tempo": "Vivace",
   "title": {
    "de": "Schmeckt und tut… einfach gut",
    "en": "Tastes good… and does you good"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-11"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Ingwerwasser mit Honig",
        "en": "Ginger water with honey"
       },
       "description": {
        "de": "frisch gepresster Ingwer mit heißem Wasser aufgegossen – wunderbar scharf und belebend",
        "en": "freshly pressed ginger infused with hot water – wonderfully fiery and invigorating"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,3l",
         "price": 3.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Rhabarberschorle",
        "en": "Rhubarb spritzer"
       },
       "description": {
        "de": "mit Orangenscheibe und frischer Minze",
        "en": "with a slice of orange and fresh mint"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.8
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Hausgemachte Limonade",
        "en": "Homemade lemonade"
       },
       "description": {
        "de": "in den Sorten Waldmeister, Kirsch, Himbeer und Erdbeer-Rhabarber",
        "en": "choose from woodruff, cherry, raspberry or strawberry-rhubarb"
       },
       "allergens": "B",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Limetten-Gurken-Wasser",
        "en": "Lime & cucumber water"
       },
       "description": {
        "de": "frisch gepresste Limette mit Mineralwasser und Gurke",
        "en": "freshly squeezed lime with mineral water and cucumber"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Limettenwasser",
        "en": "Lime water"
       },
       "description": {
        "de": "frisch gepresste Limette mit Mineralwasser",
        "en": "freshly squeezed lime with mineral water"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Hausgemachter Eistee",
        "en": "Homemade iced tea"
       },
       "description": {
        "de": "aus Beerentee und frisch gepresstem Orangensaft / aus Zitronentee und frisch gepresstem Orangensaft / aus Pfirsichtee und Pfirsich-Nektar / aus Apfeltee, 100% Apfelsaft und Minze",
        "en": "berry tea with freshly squeezed orange juice / lemon tea with freshly squeezed orange juice / peach tea with peach nectar / apple tea with 100% apple juice and mint"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,3l",
         "price": 3.9
        },
        {
         "size": "0,5l",
         "price": 5.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "saftbar",
   "group": "drinks",
   "tempo": "Giocoso",
   "title": {
    "de": "Saftbar",
    "en": "Juice bar"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "Apfelsaft, Orangensaft, Ananassaft, Grapefruitsaft, Pfirsich-Nektar, Johannisbeer-Nektar, Kirsch-Nektar, Maracuja-Nektar, Bananen-Nektar, Cranberry-Nektar, Mango-Nektar",
    "en": "Apple juice, orange juice, pineapple juice, grapefruit juice, peach nectar, blackcurrant nectar, cherry nectar, passion fruit nectar, banana nectar, cranberry nectar, mango nectar"
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-12"
   ],
   "groups": [
    {
     "title": {
      "de": "Alle Säfte und Nektare gibt's",
      "en": "All juices and nectars are available"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Pur",
        "en": "Pure"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,2l",
         "price": 2.9
        },
        {
         "size": "0,4l",
         "price": 4.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mit Buttermilch",
        "en": "With buttermilk"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,4l",
         "price": 3.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": "Nur in 0,4l gedruckt."
      },
      {
       "name": {
        "de": "Als Schorle",
        "en": "As a spritzer (with sparkling water)"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,2l",
         "price": 2.8
        },
        {
         "size": "0,4l",
         "price": 3.8
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Frisch gepresster Orangensaft",
        "en": "Freshly squeezed orange juice"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,1l",
         "price": 2.8
        },
        {
         "size": "0,3l",
         "price": 4.3
        },
        {
         "size": "0,5l",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Vitaminbombe",
        "en": "Vitamin bomb"
       },
       "description": {
        "de": "aus frisch gepresstem O-Saft, Ingwer und Karotten",
        "en": "made from freshly squeezed orange juice, ginger and carrots"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,3l",
         "price": 4.6
        },
        {
         "size": "0,5l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "erfrischendes",
   "group": "drinks",
   "tempo": "Scherzo",
   "title": {
    "de": "Erfrischendes",
    "en": "Refreshments"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-13"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Acqua Morelli still",
        "en": "Acqua Morelli still"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 2.8
        },
        {
         "size": "0,75l",
         "price": 6.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Acqua Morelli spritzig",
        "en": "Acqua Morelli sparkling"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 2.8
        },
        {
         "size": "0,75l",
         "price": 6.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Coca-Cola",
        "en": "Coca-Cola"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "A,C,E",
       "prices": [
        {
         "size": "0,2l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Coca-Cola Zero",
        "en": "Coca-Cola Zero"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "B,C,E,G",
       "prices": [
        {
         "size": "0,2l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mezzo Mix",
        "en": "Mezzo Mix"
       },
       "description": {
        "de": "",
        "en": "cola & orange soda"
       },
       "allergens": "A,C",
       "prices": [
        {
         "size": "0,2l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Bionade",
        "en": "Bionade"
       },
       "description": {
        "de": "Holunder, Ingwer-Orange, Naturtrübe Orange, Zitrone",
        "en": "organic soft drink – elderberry, ginger-orange, naturally cloudy orange or lemon"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,33l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Red Bull",
        "en": "Red Bull"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "A,C",
       "prices": [
        {
         "size": "0,25l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Ginger Ale",
        "en": "Ginger ale"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "A",
       "prices": [
        {
         "size": "0,2l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Bitter Lemon",
        "en": "Bitter lemon"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "D",
       "prices": [
        {
         "size": "0,2l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Tonic Water",
        "en": "Tonic water"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "D",
       "prices": [
        {
         "size": "0,2l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Orangina",
        "en": "Orangina"
       },
       "description": {
        "de": "gelb, rot",
        "en": "yellow (classic) or red (blood orange)"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "prosecco",
   "group": "drinks",
   "tempo": "Brillante",
   "title": {
    "de": "Prosecco & Co",
    "en": "Prosecco & Co"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-14"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Prosecco Frizzante",
        "en": "Prosecco Frizzante"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.7
        },
        {
         "size": "0,75l",
         "price": 25.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Prosecco Spumante",
        "en": "Prosecco Spumante"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,75l",
         "price": 33.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Prosecco Schorle",
        "en": "Prosecco Spritzer (Prosecco & sparkling water)"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,2l",
         "price": 4.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Aperol Sprizz",
        "en": "Aperol Spritz"
       },
       "description": {
        "de": "Prosecco auf Eis mit Aperol und Mineralwasser",
        "en": "Prosecco on ice with Aperol and mineral water"
       },
       "allergens": "A,D",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Sarti Pink",
        "en": "Sarti Pink"
       },
       "description": {
        "de": "Sarti Rosa, Goldberg Pink Grapefruit, getrocknete Grapefruitscheibe von Goldberg Secret Garden",
        "en": "Sarti Rosa, Goldberg Pink Grapefruit, dried grapefruit slice from Goldberg Secret Garden"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Limoncello Sprizz",
        "en": "Limoncello Spritz"
       },
       "description": {
        "de": "Prosecco auf Eis mit Limoncello, Mineralwasser, frischer Minze und Limette",
        "en": "Prosecco on ice with limoncello, mineral water, fresh mint and lime"
       },
       "allergens": "A",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Hugo",
        "en": "Hugo"
       },
       "description": {
        "de": "Prosecco auf Eis mit Holunderblütensirup, Limette und frischer Minze",
        "en": "Prosecco on ice with elderflower syrup, lime and fresh mint"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Rosalie",
        "en": "Rosalie"
       },
       "description": {
        "de": "Prosecco auf Eis mit Rosensirup(A,B), Limette und frischer Minze",
        "en": "Prosecco on ice with rose syrup (A,B), lime and fresh mint"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Louis Roederer",
        "en": "Louis Roederer"
       },
       "description": {
        "de": "Champagne Collection",
        "en": "Champagne Collection"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,7l",
         "price": 119.0
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Matilda Sprizz",
        "en": "Matilda Spritz"
       },
       "description": {
        "de": "Prosecco auf Eis mit Mangosirup(A,B), Maracuja-Nektar, Limette und frischer Minze",
        "en": "Prosecco on ice with mango syrup (A,B), passion fruit nectar, lime and fresh mint"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Sally",
        "en": "Sally"
       },
       "description": {
        "de": "Prosecco auf Eis mit Cranberry-Nektar, Grenadine, Mineralwasser, Limette und frischer Minze",
        "en": "Prosecco on ice with cranberry nectar, grenadine, mineral water, lime and fresh mint"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Lillet Sprizz",
        "en": "Lillet Spritz"
       },
       "description": {
        "de": "Lillet Sprizz mit Wildberry und gefrorenen Himbeeren",
        "en": "Lillet Spritz with Wildberry and frozen raspberries"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Campari Sprizz",
        "en": "Campari Spritz"
       },
       "description": {
        "de": "Campari mit Prosecco auf Eis und Limette",
        "en": "Campari and Prosecco on ice with lime"
       },
       "allergens": "A",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Campari Amalfi",
        "en": "Campari Amalfi"
       },
       "description": {
        "de": "Campari mit Bitter Lemon und Grapefruit auf Eis",
        "en": "Campari with bitter lemon and grapefruit on ice"
       },
       "allergens": "A",
       "prices": [
        {
         "size": "0,25l",
         "price": 7.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "biere",
   "group": "drinks",
   "tempo": "Maestoso",
   "title": {
    "de": "Biere",
    "en": "Beers"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-15"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Augustiner Lagerbier",
        "en": "Augustiner Lagerbier"
       },
       "description": {
        "de": "Flasche",
        "en": "Munich lager, bottle"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,33l",
         "price": 3.9
        },
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Augustiner Weißbier",
        "en": "Augustiner Weißbier"
       },
       "description": {
        "de": "Flasche",
        "en": "Bavarian wheat beer, bottle"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Augustiner Edelstoff",
        "en": "Augustiner Edelstoff"
       },
       "description": {
        "de": "Flasche",
        "en": "Munich export lager, bottle"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Jever Fun alkoholfrei",
        "en": "Jever Fun (alcohol-free)"
       },
       "description": {
        "de": "Pils",
        "en": "Pilsner"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,33l",
         "price": 3.9
        }
       ],
       "tags": [
        "alkoholfrei"
       ],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Erdinger Weißbier alkoholfrei",
        "en": "Erdinger Weißbier (alcohol-free)"
       },
       "description": {
        "de": "Flasche",
        "en": "Wheat beer, bottle"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [
        "alkoholfrei"
       ],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Radler",
        "en": "Radler (shandy)"
       },
       "description": {
        "de": "",
        "en": "Lager mixed with lemonade"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,5l",
         "price": 4.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "weine-international",
   "group": "drinks",
   "tempo": "Cantabile",
   "title": {
    "de": "Internationale Weine",
    "en": "International wines"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-16"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Primitivo",
        "en": "Primitivo"
       },
       "description": {
        "de": "Tiefdunkel und aromatisch, mit würzigen Noten und beerig-süßer Frucht. Vollmundig, moderate bis kräftige Tannine",
        "en": "Deep, dark and aromatic, with spicy notes and sweet berry fruit. Full-bodied, with moderate to firm tannins"
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": "Kein Flaschenpreis und kein Sulfit-Code gedruckt."
      },
      {
       "name": {
        "de": "Tempranillo",
        "en": "Tempranillo"
       },
       "description": {
        "de": "trockener spanischer Rotwein, 3 Monate im Eichenfass gereift mit schöner Aromenvielfalt von wilder Walderdbeere",
        "en": "Dry Spanish red, aged 3 months in oak barrels, with a lovely range of wild strawberry aromas"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        },
        {
         "size": "0,75l",
         "price": 22.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Chianti",
        "en": "Chianti"
       },
       "description": {
        "de": "trockener italienischer Rotwein, vollmundig und elegant mit Aromen von Beerenfrüchten",
        "en": "Dry Italian red, full-bodied and elegant with aromas of berry fruit"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        },
        {
         "size": "0,75l",
         "price": 23.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Nero d'Avola",
        "en": "Nero d'Avola"
       },
       "description": {
        "de": "trockener, sehr runder und weicher sizilianischer Rotwein",
        "en": "Dry Sicilian red, very round and soft"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        },
        {
         "size": "0,75l",
         "price": 22.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Skaapred Shiraz",
        "en": "Skaapred Shiraz"
       },
       "description": {
        "de": "trockener südafrikanischer Rotwein, ein komplexes, aromatisches Bouquet von schwarzen Johannisbeeren und Pflaumen",
        "en": "Dry South African red with a complex, aromatic bouquet of blackcurrant and plum"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        },
        {
         "size": "0,75l",
         "price": 22.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Lugana",
        "en": "Lugana"
       },
       "description": {
        "de": "trockener, leichter italienischer Weißwein mit zarten Mandelnoten im Abgang",
        "en": "Dry, light Italian white with delicate almond notes on the finish"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.4
        },
        {
         "size": "0,2l",
         "price": 6.7
        },
        {
         "size": "0,75l",
         "price": 25.1
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Warrelwind Sauvignon Blanc",
        "en": "Warrelwind Sauvignon Blanc"
       },
       "description": {
        "de": "erfrischender, tropisch-fruchtiger Weißwein aus Südafrika mit einem balancierten Säuregerüst",
        "en": "Refreshing, tropical and fruity white from South Africa with well-balanced acidity"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        },
        {
         "size": "0,75l",
         "price": 22.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "weine-franken-offen",
   "group": "drinks",
   "tempo": "Serenade",
   "title": {
    "de": "Offene Fränkische Qualitätsweine",
    "en": "Franconian wines by the glass"
   },
   "subtitle": {
    "de": "vom Winzerhof Blass in Erlabrunn",
    "en": "from Winzerhof Blass in Erlabrunn"
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-17"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Silvaner Kabinett",
        "en": "Silvaner Kabinett"
       },
       "description": {
        "de": "trockener Weißwein",
        "en": "dry white wine"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Riesling Kabinett",
        "en": "Riesling Kabinett"
       },
       "description": {
        "de": "trockener Weißwein",
        "en": "dry white wine"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.2
        },
        {
         "size": "0,2l",
         "price": 6.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Spätburgunder",
        "en": "Spätburgunder (Pinot Noir)"
       },
       "description": {
        "de": "trockener Rotwein",
        "en": "dry red wine"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.6
        },
        {
         "size": "0,2l",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Silvanerschorle",
        "en": "Silvaner spritzer"
       },
       "description": {
        "de": "",
        "en": "Silvaner white wine topped up with sparkling water"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,2l",
         "price": 4.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Rotling Kabinett",
        "en": "Rotling Kabinett"
       },
       "description": {
        "de": "",
        "en": "Franconian rosé-style wine from red & white grapes"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,1l",
         "price": 3.3
        },
        {
         "size": "0,2l",
         "price": 6.3
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "weine-franken-flaschen",
   "group": "drinks",
   "tempo": "Sonate",
   "title": {
    "de": "Fränkische Flaschen-Qualitätsweine",
    "en": "Franconian wines by the bottle"
   },
   "subtitle": {
    "de": "vom Juliusspital Weingut Würzburg",
    "en": "from the Juliusspital winery, Würzburg"
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-18"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Juliusspital Scheurebe",
        "en": "Juliusspital Scheurebe"
       },
       "description": {
        "de": "VDP. Gutswein – Kerniger Apfel, etwas Stachelbeere, feine Mineralik",
        "en": "VDP. Gutswein (estate wine) – crisp apple, a touch of gooseberry, fine minerality"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,75l",
         "price": 24.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Juliusspital Würzburger Silvaner",
        "en": "Juliusspital Würzburger Silvaner"
       },
       "description": {
        "de": "VDP. Ortswein, trocken – Kerniger Apfel, etwas Stachelbeere, feine Mineralik",
        "en": "VDP. Ortswein (village wine), dry – crisp apple, a touch of gooseberry, fine minerality"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,75l",
         "price": 29.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": "Auf der Karte mit identischer Beschreibung wie die Scheurebe gedruckt (vermutlich Druckfehler im Original)."
      },
      {
       "name": {
        "de": "Juliusspital Würzburger Riesling",
        "en": "Juliusspital Würzburger Riesling"
       },
       "description": {
        "de": "VDP. Gutswein, halbtrocken – Aprikose, Ananas, feines Süße-Säure-Spiel",
        "en": "VDP. Gutswein (estate wine), off-dry – apricot, pineapple, a fine interplay of sweetness and acidity"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,75l",
         "price": 29.5
        }
       ],
       "tags": [],
       "uncertain": true,
       "remark": "Erster Buchstabe von 'Aprikose' durch das Weinglas-Bild verdeckt; Lesung naheliegend."
      },
      {
       "name": {
        "de": "Juliusspital Iphöfer Domina",
        "en": "Juliusspital Iphöfer Domina"
       },
       "description": {
        "de": "VDP. Ortswein, 2021 Iphöfer Domina trocken: Tiefdunkle Farbe im Glas. In der Nase Weichselkirschen und Pflaume. Am Gaumen präsentiert er sich sehr intensiv und würzig mit Aromen von Kakao, Heidelbeeren. Zarte Tannine gepaart mit einer angenehmen Säure.",
        "en": "VDP. Ortswein (village wine), 2021 Iphöfer Domina, dry: deep, dark colour in the glass. Sour cherry and plum on the nose. On the palate it is very intense and spicy, with aromas of cocoa and blueberries. Delicate tannins paired with a pleasant acidity."
       },
       "allergens": "",
       "prices": [
        {
         "size": "0,75l",
         "price": 29.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Schoppenwein",
      "en": "Schoppen – wine by the glass"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Juliusspital Silvaner",
        "en": "Juliusspital Silvaner"
       },
       "description": {
        "de": "trocken, saftiger Apfel, Kräuterwürze, erfrischend",
        "en": "dry – juicy apple, herbal spice, refreshing"
       },
       "allergens": "12",
       "prices": [
        {
         "size": "0,2l",
         "price": 6.4
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "grappa-obstbrand",
   "group": "drinks",
   "tempo": "Con fuoco",
   "title": {
    "de": "Grappa & Obstbrände",
    "en": "Grappa & fruit brandies"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-19"
   ],
   "groups": [
    {
     "title": {
      "de": "Grappa",
      "en": "Grappa"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Grappa Scavi",
        "en": "Grappa Scavi"
       },
       "description": {
        "de": "feinstes Aroma, weicher und ausbalancierter Geschmack, 40% vol.",
        "en": "finest aroma, smooth and well-balanced taste, 40% vol."
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 4.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Obstbrände",
      "en": "Fruit Brandies"
     },
     "note": {
      "de": "vom Weingut Blass aus Erlabrunn",
      "en": "from the Blass winery in Erlabrunn"
     },
     "items": [
      {
       "name": {
        "de": "Zwetschgenwasser",
        "en": "Zwetschgenwasser"
       },
       "description": {
        "de": "",
        "en": "plum brandy"
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Williams Birne",
        "en": "Williams Birne"
       },
       "description": {
        "de": "",
        "en": "Williams pear brandy"
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Kirschwasser",
        "en": "Kirschwasser"
       },
       "description": {
        "de": "",
        "en": "cherry brandy"
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Obstler",
        "en": "Obstler"
       },
       "description": {
        "de": "",
        "en": "mixed fruit brandy"
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 3.5
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "whisky",
   "group": "drinks",
   "tempo": "Grave",
   "title": {
    "de": "Whiskys",
    "en": "Whiskies"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-20"
   ],
   "groups": [
    {
     "title": {
      "de": "",
      "en": ""
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Laphroaig",
        "en": "Laphroaig"
       },
       "description": {
        "de": "Islay Single Malt Scotch · 43% vol. · 10 Years old",
        "en": "Islay single malt Scotch whisky · 43% vol. · 10 years old"
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 4.8
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Jack Daniel's",
        "en": "Jack Daniel's"
       },
       "description": {
        "de": "Tennessee Whiskey · 40% vol.",
        "en": "Tennessee whiskey · 40% vol."
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 4.8
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Tullamore Dew",
        "en": "Tullamore Dew"
       },
       "description": {
        "de": "The Legendary Irish Whisky · 43% vol.",
        "en": "The legendary Irish whiskey · 43% vol."
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 4.8
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Bushmills Malt",
        "en": "Bushmills Malt"
       },
       "description": {
        "de": "Single Malt Irish triple distilled Whisky · 40% vol. · 10 Years old",
        "en": "Triple-distilled Irish single malt whiskey · 40% vol. · 10 years old"
       },
       "allergens": "",
       "prices": [
        {
         "size": "2cl",
         "price": 4.8
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  },
  {
   "id": "cocktails",
   "group": "drinks",
   "tempo": "Eine kleine Nachtmusik",
   "title": {
    "de": "Cocktails & Longdrinks",
    "en": "Cocktails & long drinks"
   },
   "subtitle": {
    "de": "",
    "en": ""
   },
   "note": {
    "de": "",
    "en": ""
   },
   "side_text": {
    "de": "",
    "en": ""
   },
   "source_pages": [
    "page-21",
    "page-22"
   ],
   "groups": [
    {
     "title": {
      "de": "non Alcoholics",
      "en": "Non-Alcoholic"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Virgin Colada",
        "en": "Virgin Colada"
       },
       "description": {
        "de": "Mit Ananassaft, Sahne und Cocos",
        "en": "With pineapple juice, cream and coconut"
       },
       "allergens": "7",
       "prices": [
        {
         "size": "",
         "price": 6.4
        }
       ],
       "tags": [
        "alkoholfrei"
       ],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Ipanema",
        "en": "Ipanema"
       },
       "description": {
        "de": "Mit Ingwer, Limetten, Ginger Ale und frisch gepresstem O-Saft",
        "en": "With ginger, lime, ginger ale and freshly squeezed orange juice"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.8
        }
       ],
       "tags": [
        "alkoholfrei"
       ],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Driver's Sunrise",
        "en": "Driver's Sunrise"
       },
       "description": {
        "de": "Orangen- und Zitronensaft mit Grenadine",
        "en": "Orange and lemon juice with grenadine"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.2
        }
       ],
       "tags": [
        "alkoholfrei"
       ],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Longdrinks",
      "en": "Long Drinks"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Vodka Lemon",
        "en": "Vodka Lemon"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Vodka Red Bull",
        "en": "Vodka Red Bull"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Campari Orange",
        "en": "Campari Orange"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "A",
       "prices": [
        {
         "size": "",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Gin Tonic",
        "en": "Gin & Tonic"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.7
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Gin Tonic Deluxe",
      "en": "Gin & Tonic Deluxe"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Bombay Sapphire",
        "en": "Bombay Sapphire"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Roku",
        "en": "Roku"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Tanqueray",
        "en": "Tanqueray"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Hendrick's",
        "en": "Hendrick's"
       },
       "description": {
        "de": "",
        "en": ""
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Spritzig & Herb",
      "en": "Zesty & Dry"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Caipirinha",
        "en": "Caipirinha"
       },
       "description": {
        "de": "Mit Cachaça und Limetten",
        "en": "With cachaça and lime"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Mojito",
        "en": "Mojito"
       },
       "description": {
        "de": "Mit frischer Minze und weißem Rum",
        "en": "With fresh mint and white rum"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Cuba Libre",
        "en": "Cuba Libre"
       },
       "description": {
        "de": "Mit Cola, Rum und Limetten",
        "en": "With cola, rum and lime"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.6
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Vodka Martini",
        "en": "Vodka Martini"
       },
       "description": {
        "de": "Mit grüner Olive",
        "en": "With a green olive"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 6.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    },
    {
     "title": {
      "de": "Fruchtig & Erfrischend",
      "en": "Fruity & Refreshing"
     },
     "note": {
      "de": "",
      "en": ""
     },
     "items": [
      {
       "name": {
        "de": "Touch Down",
        "en": "Touch Down"
       },
       "description": {
        "de": "Mit Vodka, Maracuja-Nektar und Apricot Brandy",
        "en": "With vodka, passion fruit nectar and apricot brandy"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 8.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "43 Sunset",
        "en": "43 Sunset"
       },
       "description": {
        "de": "Mit Likör 43, Ananassaft und Cocos",
        "en": "With Licor 43, pineapple juice and coconut"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 8.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Pina Colada",
        "en": "Pina Colada"
       },
       "description": {
        "de": "Karibischer Traum mit Coconut Cream und Rum",
        "en": "A Caribbean dream with coconut cream and rum"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 8.2
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      },
      {
       "name": {
        "de": "Tequila Sunrise",
        "en": "Tequila Sunrise"
       },
       "description": {
        "de": "Mit Grenadine, Zitrone, Tequila, Orangensaft",
        "en": "With grenadine, lemon, tequila and orange juice"
       },
       "allergens": "",
       "prices": [
        {
         "size": "",
         "price": 7.9
        }
       ],
       "tags": [],
       "uncertain": false,
       "remark": ""
      }
     ]
    }
   ]
  }
 ]
};
